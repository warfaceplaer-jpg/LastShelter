package com.lastshelter.game;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.view.View;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
  WebView web = new WebView(this);
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(true);
  web.setBackgroundColor(0xff102434);
  web.loadUrl("file:///android_asset/index.html");
  setContentView(web);
 }
}
